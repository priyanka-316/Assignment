package access_modifier;

public class Default_AM_test {
void show() {
	System.out.println("Default method");
}
}
