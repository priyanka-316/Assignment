package access_modifier;
import packageeg.*;
public class Default_AM {
public static void main(String args[]) {
	Default_AM_test obj = new Default_AM_test ();
	obj.show();
	
}
}
