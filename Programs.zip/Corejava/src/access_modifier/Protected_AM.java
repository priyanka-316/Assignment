package access_modifier;
import packageeg.Protected_AM_Test;
// if you want to access it is possible 

public class Protected_AM extends Protected_AM_Test{

	public static void main(String args[]) {

	 Protected_AM ob = new  Protected_AM();
	 ob.result();
}
}